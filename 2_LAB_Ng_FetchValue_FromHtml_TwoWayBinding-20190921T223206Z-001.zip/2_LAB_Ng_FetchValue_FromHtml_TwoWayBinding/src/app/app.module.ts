import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

import { Lab1GetValueFromViewToComponentComponent } from './lab/lab1/lab1-get-value-from-view-to-component/lab1-get-value-from-view-to-component.component';
import { Lab2TwowayBindingComponent } from './lab/lab2-twoway-binding/lab2-twoway-binding.component';

@NgModule({
  declarations: [
    AppComponent,
    Lab1GetValueFromViewToComponentComponent,
    Lab2TwowayBindingComponent,
  ],
  imports: [
    BrowserModule
   , FormsModule   // TWO WAY BINDING  , it is library given by anguar
  ],


  providers: [], // step 2- for service calling
  bootstrap: [AppComponent] // first file to be called , root component , it is kept in index.html
})
export class AppModule { }
