import { Component} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']

})
export class AppComponent  {

  title = 'This is a component level understanding ';
  passion= '';
  ParentValue= '';
  testdata= 'hi guys ';
 }
