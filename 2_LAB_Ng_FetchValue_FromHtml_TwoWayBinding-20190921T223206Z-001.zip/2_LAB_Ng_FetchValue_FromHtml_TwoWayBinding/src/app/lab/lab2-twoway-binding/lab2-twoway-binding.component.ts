
// step 1: import
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'Lab2',
  templateUrl: './lab2-twoway-binding.component.html',
  styleUrls: ['./lab2-twoway-binding.component.css']
})
export class Lab2TwowayBindingComponent {

  
  // Step 2: variable , which will be in HTML text box
  name1 ="Angular Two way Binding!!!";

  //step 3: create method
  

}
