import { Component, OnInit,ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'Lab1',
  templateUrl: './lab1-get-value-from-view-to-component.component.html',
  styleUrls: ['./lab1-get-value-from-view-to-component.component.css']
})

export class Lab1GetValueFromViewToComponentComponent 
{
  // variable
   title ='';
  
 // @ViewChild let you access a control from  HTML file
 @ViewChild('EmpName', {static: false}) textBox: ElementRef;  // given by angular ElementRef

 // this method getting called from HTML file
 myMethod()
 {
  alert('I am from  ts file:=> ' + this.textBox.nativeElement.value);
  
  this.title = this.textBox.nativeElement.value;
 }

// this method getting called from HTML file
myMethod2(msg:string )
{
  alert('I am from ts file :-'+msg);

  // putting into variable
  this.title=msg;
}




}

